
Install Java

       1.Download Java SDK 1.8 https://www.oracle.com/java/technologies/javase-jdk8-downloads.html 

How to run Test cases

1.By using command prompt run 'mvn clean install'.
2.Please run the 'mvn test'
